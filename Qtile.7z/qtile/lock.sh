#!/bin/bash

exec xautolock -detectsleep \
	-corners +-00 \
	-time 10 -locker "i3lock -i Downloads/846636.png" \
	-notify 5 \
	-notifier "notify-send -u critical -t 5000 -- 'LOCKING screen in 5 seconds'"
