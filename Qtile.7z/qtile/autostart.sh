#!/bin/sh

volumeicon &
xfce4-power-manager &
dunst &
lxsession &
nm-applet &
redshift-gtk -l 43.64:21.87 &
xclip &
nitrogen --restore &
picom &
sleep 2 && conky -c ~/.dracula.conkyrc &
sh /home/punky/.config/qtile/lock.sh &
